/*
 * Copyright (C) 2018 Square, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package okhttp3.sse.internal

import assertk.assertThat
import assertk.assertions.isEqualTo
import mockwebserver3.MockResponse
import mockwebserver3.MockWebServer
import mockwebserver3.junit5.StartStop
import okhttp3.Headers
import okhttp3.OkHttpClientTestRule
import okhttp3.Request
import okhttp3.sse.EventSources.processResponse
import okhttp3.testing.PlatformRule
import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.Tag
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.RegisterExtension

@Tag("Slowish")
class EventSourcesHttpTest {
  @RegisterExtension
  val platform = PlatformRule()

  @StartStop
  private val server = MockWebServer()

  @RegisterExtension
  val clientTestRule = OkHttpClientTestRule()

  private val listener = EventSourceRecorder()
  private val client = clientTestRule.newClient()

  @AfterEach
  fun after() {
    listener.assertExhausted()
  }

  @Test
  fun processResponse() {
    server.enqueue(
      MockResponse
        .Builder()
        .body(
          """
          |data: hey
          |
          |
          """.trimMargin(),
        ).setHeader("content-type", "text/event-stream")
        .build(),
    )
    val request = Request.Builder().url(server.url("/")).build()
    val response = client.newCall(request).execute()
    processResponse(response, listener)
    listener.assertOpen()
    listener.assertEvent(null, null, "hey")
    listener.assertClose()
  }

  @Test
  fun cancelShortCircuits() {
    server.enqueue(
      MockResponse
        .Builder()
        .body(
          """
          |data: hey
          |
          |
          """.trimMargin(),
        ).setHeader("content-type", "text/event-stream")
        .build(),
    )
    listener.enqueueCancel() // Will cancel in onOpen().
    val request = Request.Builder().url(server.url("/")).build()
    val response = client.newCall(request).execute()
    processResponse(response, listener)
    listener.assertOpen()
    listener.assertFailure("canceled")
  }

  @Test
  fun failureWith401IsReadable() {
    server.enqueue(
      MockResponse(
        code = 401,
        body = "{\"error\":{\"message\":\"No auth credentials found\",\"code\":401}}",
        headers = Headers.headersOf("content-type", "application/json"),
      ),
    )
    server.enqueue(
      MockResponse(
        body =
          """
          |data: hey
          |
          |
          """.trimMargin(),
        headers = Headers.headersOf("content-type", "text/event-stream"),
      ),
    )

    val request1 = Request.Builder().url(server.url("/")).build()
    val response1 = client.newCall(request1).execute()
    assertThat(response1.code).isEqualTo(401)
    assertThat(response1.body.string())
      .isEqualTo("{\"error\":{\"message\":\"No auth credentials found\",\"code\":401}}")

    val request2 = request1.newBuilder().header("Authorization", "XYZ").build()
    val response2 = client.newCall(request2).execute()
    processResponse(response2, listener)
    listener.assertOpen()
    listener.assertEvent(null, null, "hey")
    listener.assertClose()
  }
}
