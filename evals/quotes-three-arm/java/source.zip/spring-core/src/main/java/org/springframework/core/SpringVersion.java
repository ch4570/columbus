/*
 * Copyright 2002-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.core;

import org.jspecify.annotations.Nullable;

/**
 * Class that exposes the Spring version. Fetches the
 * "Implementation-Version" manifest attribute from the jar file.
 *
 * <p>Note that some ClassLoaders do not expose the package metadata,
 * hence this class might not be able to determine the Spring version
 * in all environments. Consider using a reflection-based check instead &mdash;
 * for example, checking for the presence of a specific Spring method that you
 * intend to call.
 *
 * @author Juergen Hoeller
 * @since 1.1
 */
public final class SpringVersion {

	private SpringVersion() {
	}


	/**
	 * Return the "major.minor.patch" version string of the present Spring codebase,
	 * or {@code null} if it cannot be determined.
	 * @see Package#getImplementationVersion()
	 */
	public static @Nullable String getVersion() {
		Package pkg = SpringVersion.class.getPackage();
		String version = (pkg != null ? pkg.getImplementationVersion() : null);
		if (version != null) {
			int idx = version.indexOf('.');  // after major
			if (idx != -1) {
				idx = version.indexOf('.', idx + 1);  // after minor
				if (idx != -1) {
					idx = version.indexOf('.', idx + 1);  // after patch
					if (idx != -1) {
						// Ignore anything beyond "major.minor.patch"
						version = version.substring(0, idx);
					}
				}
			}
		}
		return version;
	}

}
