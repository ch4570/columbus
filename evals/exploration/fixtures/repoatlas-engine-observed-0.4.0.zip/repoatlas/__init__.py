"""RepoAtlas: local repository intelligence, without LLM indexing calls."""
__version__ = "0.4.0"
