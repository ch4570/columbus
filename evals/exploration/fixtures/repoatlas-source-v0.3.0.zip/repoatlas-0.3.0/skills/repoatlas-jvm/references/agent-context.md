---
title: Budgeted agent context
source: ../scripts/repoatlas/retrieval.py
last_fetched: 2026-09-07
skills: [repoatlas-jvm]
---

# Budgeted retrieval

`map` ranks declarations by incoming non-containment dependencies; a query uses exact-name and FTS lexical ranking. It emits signatures/locations, no source bodies. The selection is bounded to 200 candidates (50 with a query); inspect `truncated`.

`context --mode signatures` combines lexical results and one-hop calls/inheritance/imports without source-body reads. `--mode snippets` verifies selected file hashes and returns at most 80 lines per candidate within the total budget. Whole-file matches can search beyond the first 12,000 characters and choose an excerpt around the query. Overlapping line ranges are emitted once.

`--exclude-id` removes already-seen candidate IDs. Exclusions are caller-owned, do not persist, and do not imply source verification. They filter exact symbol IDs, not every overlapping parent/child ID in the file. Excluding a truncated symbol also excludes its unread remainder. Reuse them only while `revision` is unchanged. Source read failures increment `stale_candidates`; no stale source is returned as verified.

`--budget-bytes` accepts 2048–64000. `--budget-tokens` accepts 700–21000 and tightens the byte cap to `min(budget_bytes, tokens * 3)`. The packet is measured in its complete compact JSON form, including accounting and policy fields; CLI adds no newline. `estimated_tokens` is `ceil(UTF-8 bytes / 3)`, not an exact model tokenizer. MCP adds its envelope/serialization overhead.

`economy.indexed_source_bytes`, `response_bytes`, and `source_bytes_returned` enable reproducible payload comparisons. They do not establish real task-quality or model-cost savings. Use an equal-task model-usage experiment for those claims.

## 리뷰 훅

- Does the complete payload fit, including Unicode and metadata?
- Are source hashes, graph revision, omissions, and estimates distinguished?
- Have exclusions been cleared after a revision change?
