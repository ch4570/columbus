# Polyglot navigation fixture

This repository-shaped fixture exercises TypeScript imports/calls, Go and Rust
functions, C++ local includes/calls, an extensionless Python script, a custom
workflow language, and unknown text fallback. It is static input, not a runnable
multi-service application.

```sh
repoatlas index examples/polyglot-demo
repoatlas search checkout
repoatlas graph --format mermaid
```

`.repoatlas.json` adds `.flow` as `workflow` and recognizes the literal `task`
declaration keyword. No repository code or custom plugin executes. The fixture
intentionally makes no cross-language runtime call claims.
