# RepoAtlas

레포를 로컬 코드 그래프로 색인하고, 에이전트가 **작은 지도 → 심볼 → 필요한 코드** 순서로 탐색하게 하는 도구입니다. JVM 전용 스킬을 다언어 CLI·설치형 스킬·MCP 서버로 확장했습니다. 색인에 LLM이나 API 키가 필요하지 않으며 대상 프로젝트를 빌드하거나 실행하지 않습니다.

## 설치하고 바로 쓰기

Python **3.11 이상**과 SQLite FTS5가 필요합니다. `dist/`의 wheel을 원하는 위치로 옮겨 설치합니다. 최초 설치에는 인터넷이 필요하며, 오프라인 방법은 아래에 있습니다.

```bash
pipx install /path/to/repoatlas-0.3.0-py3-none-any.whl
# 또는
uv tool install /path/to/repoatlas-0.3.0-py3-none-any.whl
```

pip만 있다면 전용 가상환경에 설치합니다.

```bash
python3 -m venv /path/to/atlas-env
/path/to/atlas-env/bin/python -m pip install /path/to/repoatlas-0.3.0-py3-none-any.whl
/path/to/atlas-env/bin/repoatlas doctor
```

Windows는 가상환경의 `Scripts/python.exe`, `Scripts/repoatlas.exe`를 사용합니다. 명령을 PATH에 둔 경우 어느 디렉터리에서든 다음처럼 실행할 수 있습니다.

```bash
repoatlas --repo /path/to/project map --budget-tokens 2000
repoatlas --repo /path/to/project search refund --limit 5
repoatlas --repo /path/to/project context refund --mode signatures --budget-tokens 1500
repoatlas --repo /path/to/project context refund --budget-tokens 2000
repoatlas --repo /path/to/project init
```

`--repo`를 생략하면 현재 디렉터리를 사용합니다. 검색·지도·컨텍스트·그래프 명령은 최초 색인과 변경 동기화를 자동으로 처리합니다. `init`은 에이전트 스킬을 설치하며 기존 관리 파일의 로컬 수정이 있으면 충돌을 알립니다. 설치 계획만 보려면 `init --plan`, Claude 경로를 쓰려면 `init --skills-dir .claude/skills`를 지정합니다.

기존 설치와 호환되도록 스킬 ID/경로는 `repoatlas-jvm`, 기본 DB는 `.repoatlas/jvm-v2.sqlite`를 유지했습니다. **이 이름이 언어를 제한하지는 않습니다.** 캐시인 `.repoatlas/`는 대상 프로젝트의 `.gitignore`에 추가하세요. 설치기는 기존 지침·훅·Git 설정을 바꾸지 않습니다.

## ZIP으로 프로젝트 전용 설치

`dist/repoatlas-0.3.0.zip`을 풀고 아래 명령을 실행하면 스킬과 전용 런타임을 함께 설치합니다. 원본 번들 폴더는 설치 후 이동해도 됩니다.

```bash
python3 install.py --repo /path/to/project
python3 run.py --repo /path/to/project map --budget-tokens 2000
python3 run.py --repo /path/to/project search refund
```

`--plan`은 읽기 전용 계획, `--no-index`는 최초 색인 생략입니다. 설치된 런타임은 `.repoatlas/runtime/`, 스킬은 `.agents/skills/repoatlas-jvm/`에 둡니다. 프로젝트 안에서 직접 실행할 수도 있습니다.

```bash
.repoatlas/runtime/bin/python -E -s .agents/skills/repoatlas-jvm/scripts/atlas.py map --repo .
```

ZIP에는 Python이나 플랫폼별 의존성 wheel이 포함되지 않습니다. 소스에서 wheel을 만들려면 `python3 -m pip wheel --no-deps --wheel-dir dist .`를 실행하세요. 이 저장소를 받은 뒤 `pipx install .` 또는 `uv tool install .`로 설치할 수도 있습니다. PyPI에 공개됐다는 전제는 없습니다.

## 어떤 언어를 인식하나

확장자·파일명·shebang과 사용자 매핑으로 언어를 감지합니다. 감지와 분석 정확도는 구분합니다.

| 분석 수준 (`fidelity`) | 대상 | 제공하는 그래프 |
| --- | --- | --- |
| `ast` | Python, Java, Kotlin | 문법 트리 기반 선언·포함·상속·보수적 호출/임포트 |
| `heuristic` | JS/TS, Go, Rust, C/C++, C#, Ruby, PHP, Swift, Dart 등 | 어휘 규칙으로 찾은 선언과 근거가 있는 관계 후보 |
| `text` | 그 밖의 UTF-8 텍스트 | 파일 노드·전체 텍스트 검색·위치 기반 컨텍스트 |

지원하지 않는 언어도 파일 그래프에 남습니다. 모든 언어의 타입·런타임 호출을 정확히 추론하는 컴파일러는 아닙니다. 심볼의 `fidelity`, 관계의 `confidence`, 미해결 참조와 진단을 함께 확인하세요. [감지 목록](skills/repoatlas-jvm/scripts/repoatlas/language_profiles.py)과 [분석 계약](skills/repoatlas-jvm/references/polyglot.md)에 범위를 명시했습니다.

자체 DSL은 `.repoatlas.json`에 확장자와 선언 키워드를 추가합니다. 실행 코드나 임의 정규식은 받지 않습니다.

```json
{
  "include": ["src/*", "lib/*"],
  "exclude": ["**/generated/*"],
  "extensions": {".acme": "acme"},
  "declarations": {"acme": ["procedure", "routine"]}
}
```

설정 변경도 색인을 갱신합니다. `.repoatlasignore`는 계속 사용할 수 있습니다. Git의 무시된 미추적 파일, 의존성·빌드 폴더, symlink, 알려진 비밀 파일, 바이너리, 1MB 초과 파일은 제외합니다. 알려진 확장자는 변경 없는 동기화에서 본문을 다시 읽지 않으며, 알 수 없는 확장자는 텍스트 여부를 확인한 비용을 `inventory.probe_files/probe_bytes`로 표시합니다.

## 원하는 그래프 만들기

```bash
repoatlas graph --repo /path/to/project --format html --output /tmp/graph.html
repoatlas graph --repo /path/to/project --format mermaid --level file --kinds imports calls --output /tmp/dependencies.mmd
repoatlas graph --repo /path/to/project --format graphml --language typescript --path 'src/*' --output /tmp/frontend.graphml
repoatlas graph --repo /path/to/project --format json --focus 'EXACT_SYMBOL_ID' --hops 2 --kinds calls --output /tmp/flow.json
```

JSON은 자동화, Mermaid는 문서, GraphML은 외부 그래프 도구, HTML은 오프라인 탐색용입니다. `--level file`은 파일 간 관계로 묶고, 기본값 `symbol`은 선언별 그래프를 유지합니다. `--direction in`은 들어오는 관계를 봅니다. `--focus`와 `symbol`, `neighbors`, `impact`에는 검색 결과의 실제 ID를 넣으세요. 기존 출력 파일은 덮어쓰지 않습니다.

전체 그래프는 기본 1,000노드, 최대 5,000노드입니다. 중심 탐색은 최대 200노드·3홉이며, 관계 수도 제한합니다. `truncated`가 참이면 범위를 나누어 조회하세요.

## 에이전트 입력 줄이기

| 명령 | 반환 내용 | 소스 본문 읽기 |
| --- | --- | --- |
| `map [QUERY]` | 중요 선언·위치·언어별 개요 | 조회 자체는 읽지 않음 |
| `search QUERY` | 정확한 ID와 검색 후보 | 조회 자체는 읽지 않음 |
| `context QUERY --mode signatures` | 후보와 가까운 관계의 선언 | 조회 자체는 읽지 않음 |
| `context QUERY --mode snippets` | 해시를 확인한 필요한 코드 | 선택한 파일만 |
| `symbol ID` | 지정한 선언의 현재 코드 | 해당 파일만 |

위 표는 동기화 이후의 조회를 뜻합니다. 최초 색인은 소스를 읽습니다. 컨텍스트 안에서는 겹치는 코드 줄을 한 번만 반환합니다. `--exclude-id ID`를 반복하면 이미 받은 **동일 심볼**을 제외합니다. 다른 ID의 부모·자식 선언까지 제외하는 기능은 아니며, 부분 출력된 심볼을 제외하면 나머지 코드도 다시 받지 않습니다. 변경으로 `revision`이 달라지면 제외 목록을 비우세요.

- `--budget-bytes`: 메타데이터를 포함한 전체 compact JSON의 UTF-8 바이트 한도(2,048–64,000).
- `--budget-tokens`: `ceil(UTF-8 JSON bytes / 3)` 추정치의 한도(700–21,000). 모델별 정확한 토큰 수는 다릅니다. 두 옵션을 쓰면 더 작은 한도를 적용합니다.
- `economy`: 전체 색인 소스 크기, 실제 응답 크기, 반환한 소스 크기. 모델 사용량이나 요금 절감률과는 별도입니다.

재현 가능한 입력 크기 측정:

```bash
python3 scripts/benchmark_context.py
python3 scripts/benchmark_context.py --repo /path/to/project --query refund --budget-tokens 2000
```

에이전트에는 다음처럼 지시할 수 있습니다.

> `.agents/skills/repoatlas-jvm/SKILL.md`를 읽고, 2,000 추정 토큰 이내의 map부터 시작해줘. 관련 ID와 관계로 범위를 좁힌 다음 필요한 코드만 읽고 수정해줘. 수정 후 테스트와 sync도 실행해줘.

## MCP

선택 의존성을 설치한 인터프리터에서 `serve`를 실행합니다.

```bash
python3 -m pip install '/path/to/repoatlas-0.3.0-py3-none-any.whl[mcp]'
repoatlas sync --repo /path/to/project
repoatlas serve --repo /path/to/project
```

stdio 클라이언트 설정 예시입니다. `command`에는 설치된 명령의 실제 절대 경로를 쓰세요.

```json
{"mcpServers":{"repoatlas":{"command":"/absolute/path/to/repoatlas","args":["serve","--repo","/absolute/path/to/project"]}}}
```

`repository_map`, `index_status`, `find_symbols`, `read_symbol`, `graph_neighbors`, `build_context`, `impact_analysis` 일곱 도구를 제공합니다. MCP는 읽기 전용 스냅샷 조회이며 자동 동기화하지 않습니다. 수정·브랜치 변경 뒤 CLI `sync`를 실행하세요. MCP 전송 봉투와 텍스트 직렬화 비용은 core JSON 예산에 포함되지 않습니다.

## 오프라인 설치와 업데이트

같은 OS·CPU·Python 환경에서 휠을 다운로드해 번들과 함께 옮깁니다.

```bash
python3 -m pip download --only-binary=:all: --dest /path/to/wheels -r skills/repoatlas-jvm/scripts/requirements.txt
python3 install.py --repo /path/to/project --offline --wheelhouse /path/to/wheels
```

MCP도 필요하면 다운로드 시 `requirements-mcp.txt`, 설치 시 `--mcp`를 지정합니다. 전역 설치는 `pip install --no-index --find-links /path/to/wheels /path/to/repoatlas-0.3.0-py3-none-any.whl`을 사용합니다.

업데이트는 새 wheel을 다시 설치하고 `repoatlas init --repo PATH`를 실행하거나, 새 ZIP의 `install.py`를 실행합니다. 관리 파일의 로컬 수정은 덮어쓰지 않습니다. 전용 런타임 소유권·설치 잠금·실패 시 복구도 유지합니다. 잠금이 남으면 실행 중인 설치가 없는지 확인한 뒤 빈 잠금 폴더를 제거하세요.

## 개발과 검증

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -e '.[mcp]'
.venv/bin/python -m unittest discover -s tests -v
# 엔진 테스트는 skills/repoatlas-jvm/scripts 디렉터리에서:
/path/to/repo/.venv/bin/python -m unittest discover -s tests -v
# 배포 파일 생성 및 새 환경 검증:
.venv/bin/python -m pip wheel --no-deps --wheel-dir dist .
.venv/bin/python scripts/build_bundle.py
.venv/bin/python scripts/verify_distribution.py --wheel dist/repoatlas-0.3.0-py3-none-any.whl --bundle dist/repoatlas-0.3.0.zip
```

MIT 라이선스. 실행한 환경·테스트·측정값과 미검증 범위는 [VALIDATION.md](VALIDATION.md)에 기록합니다. Linux/macOS/Windows와 Python 3.11/3.14의 배포 검증 워크플로도 포함했습니다.
