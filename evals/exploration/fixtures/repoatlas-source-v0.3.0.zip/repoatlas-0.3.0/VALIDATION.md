# RepoAtlas 0.3.0 검증

2026-09-07 현재 작업 트리에서 배포와 엔진을 검증했습니다. 이전 0.2.0의 Linux 검증 기록을 이번 버전의 증거로 재사용하지 않습니다.

## 실제 설치

macOS arm64에서 Python 3.11.14와 3.14.7을 사용했습니다. 고정 의존성 Tree-sitter 0.26.0, Java 0.23.5, Kotlin 1.1.0, 선택 MCP SDK 2.1.1을 설치했습니다.

| 검증 | 관찰 결과 |
| --- | --- |
| wheel → 새 venv 설치 | 다른 작업 디렉터리·공백 포함 경로에서 doctor/search/init 성공 |
| pipx·uv tool 설치 | 각각 격리된 설치 경로에서 전역 명령과 스킬 설치 성공 |
| ZIP → 프로젝트 전용 설치 | 런타임 생성, 최초 색인, 재설치 noop, runner 실행 성공 |
| 원본 번들 이동 | 설치된 스킬과 런타임만으로 doctor 실행 성공 |
| ZIP → wheel 재빌드 | 배포 ZIP만으로 pip wheel 빌드 성공 |
| 오프라인 wheelhouse | 네트워크 색인 없이 새 설치와 전용 런타임 재설치 성공 |
| 관리 파일 충돌 | 로컬 수정 보존, 덮어쓰기 거부 |
| 체크섬·재현성 | ZIP 내부 전체 파일 SHA-256 검사, 같은 입력의 ZIP 바이트 동일 |

Linux/Windows 네이티브 실행은 이 세션에서 하지 않았습니다. 세 OS × Python 3.11/3.14의 GitHub Actions 배포 검증을 작성했으며 원격 CI 실행 결과와는 구분합니다.

## 엔진 회귀 검증

검증 명령:

```bash
python -m unittest discover -s tests -v
# skills/repoatlas-jvm/scripts 안에서:
python -m unittest discover -s tests -v
```

- Python/JVM 기존 선언·오버로드·shadowing·호출 후보 테스트.
- 증분·삭제·브랜치·worktree·설정 변경, 전체 재빌드 동등성, 동시 변경 감지, 스키마 거부.
- 다언어 자동 감지와 선언, 타입이 불확실한 receiver 미해결 처리, 댓글·문자열·raw string·정규식 오인 방지.
- JS/TS 인자 없는 화살표 함수, optional chaining, 공백을 둔 receiver, Perl namespace 회귀.
- 미지원 UTF-8 파일·shebang·사용자 선언 키워드, 바이너리·비밀 파일·symlink·크기 제한.
- 원문 없는 map/signatures, 현재 소스 해시, 겹치는 줄 제거, 정확한 JSON 바이트 예산과 경계 메타데이터.
- 파일/심볼 그래프, 범위 필터, HTML 삽입 방어, GraphML XML, Mermaid escaping.
- 실제 MCP stdio initialize → 7도구 발견 → map/search/symbol/neighbors/impact/context 호출과 인자 오류.

최종 엔진 **129개**, 루트 설치·배포 **18개**가 모두 통과했습니다. MCP를 포함해 건너뛴 테스트는 없습니다. 배포 파일 체크섬은 `dist/SHA256SUMS.txt`와 ZIP의 `.sha256` 파일에 둡니다.

## 입력 크기 재현 측정

`python scripts/benchmark_context.py`는 하나의 환불 함수와 관련 없는 100파일을 생성합니다. 전체 색인 소스는 **383,336바이트**입니다. map/signatures/snippets 응답은 각각 약 **1.1KB**였고, 변경 없는 fast sync의 `parsed_files`, `hashed_files`, `hashed_bytes`는 모두 0입니다.

이는 의도적으로 작은 관련 코드가 있는 합성 예제입니다. 전체 소스 대비 응답 바이트를 비교하며, 에이전트의 실제 작업 성공률·입력 토큰·캐시·출력 비용이나 요금 절감률을 측정하지 않습니다. 모델별 토큰 수는 UTF-8 바이트의 1/3이라는 추정치와 다를 수 있습니다.

## 한계

- Python/Java/Kotlin 외 분석은 heuristic 또는 text 수준입니다. 모든 언어의 의미·타입·동적 호출을 증명하지 않습니다.
- 알 수 없는 확장자는 텍스트 판별을 위해 내용을 확인합니다. discovery probe 비용은 별도 표시합니다.
- 최초 색인은 파일을 읽고, 관계 변경 때는 캐시된 사실을 전체 재연결합니다. 운영 규모 모노레포의 성능 상한은 측정하지 않았습니다.
- 스킬 파일 설치와 명령 실행은 검증했지만 모든 에이전트 제품의 자동 발견이나 실제 장기 코딩 작업을 보장하지 않습니다.
- 모델 토크나이저나 NVIDIA SkillEvaluator는 새 프로젝트 의존성으로 추가하지 않았습니다.


## 실제 저장소와 혼합 언어 예제

- 이 저장소 자체 색인: 74파일·487심볼·940관계, 색인 소스 399,855바이트. `build_context` 선언 조회는 5,921바이트/1,974 추정 토큰, stale 후보 0개였습니다. 소스 변경에 따라 이후 수치는 달라집니다.
- 혼합 언어 예제: 9개 감지 언어, 28심볼·25관계. 파일 그래프 11노드·4관계. TypeScript checkout 중심 그래프 2노드·1호출 관계.
- JSON·Mermaid·GraphML·HTML 파일 생성, GraphML XML 파싱과 dangling edge 방지를 검증했습니다. HTML 화면의 브라우저 조작은 이 세션에서 실행하지 않았습니다.
- Python 3.11 문법 검사, compileall, pip check, Markdown 내부 링크 검사 통과. 별도 lint/typecheck 도구 설정이나 의존성이 없어 프로젝트에 새 검사 패키지를 추가하지 않았습니다.
- 스킬 frontmatter·경로·내부 링크와 설치본 파일 체크섬을 검사했습니다. 공식 quick_validate는 검사 환경의 PyYAML 부재로 실행되지 않았으며, NVIDIA SkillEvaluator 평가도 수행하지 않았습니다.
